# বাঁশবাগান — Remotion প্রজেক্ট (16:9, 1920×1080, 30fps)

```
npm install
npx remotion studio src/index.ts      # প্রিভিউ
npx remotion render src/index.ts Bashbagan out/bashbagan.mp4 --codec=h264
```
- অডিও: `public/voice.mp3`
- সিন/টাইমিং/সংলাপ: `src/story.ts`
- ক্যারেক্টার: `src/Character.tsx`, ব্যাকগ্রাউন্ড: `src/Backgrounds.tsx`
