import React from 'react';

export type IconType =
  | 'warning'
  | 'question'
  | 'exclaim'
  | 'ghost'
  | 'ghostx'
  | 'clock'
  | 'hourglass'
  | 'skull'
  | 'nupur'
  | 'bamboo'
  | 'moon'
  | 'wave'
  | 'heart';

const O = '#222222';

export const Icon: React.FC<{type: IconType; size?: number; frame?: number}> = ({type, size = 120, frame = 0}) => {
  let body: React.ReactNode = null;
  switch (type) {
    case 'warning':
      body = (
        <g>
          <path d="M50 10 L93 86 L7 86Z" fill="#f2c230" stroke={O} strokeWidth={4} strokeLinejoin="round" />
          <rect x={46} y={36} width={8} height={26} rx={4} fill={O} />
          <circle cx={50} cy={73} r={5} fill={O} />
        </g>
      );
      break;
    case 'question':
    case 'exclaim':
      body = (
        <g>
          <circle cx={50} cy={50} r={42} fill={type === 'question' ? '#4aa3df' : '#e8554e'} stroke={O} strokeWidth={4} />
          {type === 'question' ? (
            <g>
              <path d="M34 38 C34 18 68 18 66 40 C65 52 50 52 50 64" fill="none" stroke="#fff" strokeWidth={9} strokeLinecap="round" />
              <circle cx={50} cy={78} r={6} fill="#fff" />
            </g>
          ) : (
            <g>
              <rect x={45} y={22} width={10} height={36} rx={5} fill="#fff" />
              <circle cx={50} cy={74} r={6} fill="#fff" />
            </g>
          )}
        </g>
      );
      break;
    case 'ghost':
    case 'ghostx':
      body = (
        <g>
          <path
            d="M20 90 V46 C20 12 80 12 80 46 V90 L68 79 L56 90 L44 79 L32 90 Z"
            fill="#f1f5f8"
            stroke={O}
            strokeWidth={4}
            strokeLinejoin="round"
          />
          <circle cx={40} cy={44} r={5} fill={O} />
          <circle cx={60} cy={44} r={5} fill={O} />
          <ellipse cx={50} cy={62} rx={7} ry={9} fill={O} />
          {type === 'ghostx' && (
            <g stroke="#e8554e" strokeWidth={9} strokeLinecap="round">
              <path d="M12 12 L88 88" />
              <path d="M88 12 L12 88" />
            </g>
          )}
        </g>
      );
      break;
    case 'clock':
      body = (
        <g>
          <circle cx={50} cy={50} r={42} fill="#f6f1e4" stroke={O} strokeWidth={5} />
          <path d="M50 14 V50 M50 50 L50 22" stroke={O} strokeWidth={6} strokeLinecap="round" />
          <circle cx={50} cy={50} r={5} fill={O} />
        </g>
      );
      break;
    case 'hourglass':
      body = (
        <g>
          <rect x={22} y={10} width={56} height={9} rx={3} fill="#7a5632" stroke={O} strokeWidth={3} />
          <rect x={22} y={81} width={56} height={9} rx={3} fill="#7a5632" stroke={O} strokeWidth={3} />
          <path d="M28 19 H72 L54 50 L72 81 H28 L46 50Z" fill="#cfe9f7" stroke={O} strokeWidth={4} strokeLinejoin="round" />
          <path d="M40 76 H60 L50 62Z" fill="#e5c27a" />
        </g>
      );
      break;
    case 'skull':
      body = (
        <g>
          <path d="M18 48 C18 14 82 14 82 48 C82 62 74 66 70 70 V82 H30 V70 C26 66 18 62 18 48Z" fill="#f1ecdc" stroke={O} strokeWidth={4} strokeLinejoin="round" />
          <ellipse cx={37} cy={48} rx={9} ry={11} fill={O} />
          <ellipse cx={63} cy={48} rx={9} ry={11} fill={O} />
          <path d="M50 58 L45 68 H55Z" fill={O} />
          <path d="M40 72 V82 M50 72 V82 M60 72 V82" stroke={O} strokeWidth={3} />
        </g>
      );
      break;
    case 'nupur':
      body = (
        <g>
          <ellipse cx={50} cy={46} rx={36} ry={14} fill="none" stroke="#c49a2c" strokeWidth={9} />
          {[18, 34, 50, 66, 82].map((cx, i) => (
            <g key={cx}>
              <circle cx={cx} cy={62 + Math.abs(2 - i) * -2 + 10} r={9} fill="#e2b84a" stroke={O} strokeWidth={3} />
              <path d={`M${cx - 5} ${70 + Math.abs(2 - i) * -2 + 4} h10`} stroke={O} strokeWidth={2} />
            </g>
          ))}
        </g>
      );
      break;
    case 'bamboo':
      body = (
        <g>
          {[28, 50, 72].map((x, i) => (
            <g key={x}>
              <rect x={x - 7} y={8 + i * 6} width={14} height={86 - i * 6} rx={4} fill="#5da05a" stroke={O} strokeWidth={3} />
              {[30, 52, 74].map((y) => (
                <path key={y} d={`M${x - 8} ${y + i * 4} h16`} stroke={O} strokeWidth={3} />
              ))}
            </g>
          ))}
        </g>
      );
      break;
    case 'moon':
      body = (
        <path d="M66 12 A40 40 0 1 0 90 66 A32 32 0 1 1 66 12Z" fill="#f4e9b8" stroke={O} strokeWidth={4} strokeLinejoin="round" />
      );
      break;
    case 'wave':
      body = (
        <g>
          {Array.from({length: 7}).map((_, i) => {
            const h = 20 + Math.abs(Math.sin(frame / 5 + i * 0.9)) * 56;
            return <rect key={i} x={8 + i * 13} y={50 - h / 2} width={8} height={h} rx={4} fill="#9ad0ff" stroke={O} strokeWidth={2.5} />;
          })}
        </g>
      );
      break;
    case 'heart':
      body = (
        <path
          d="M50 86 C10 58 8 28 28 20 C40 16 48 24 50 32 C52 24 60 16 72 20 C92 28 90 58 50 86Z"
          fill="#e5484d"
          stroke={O}
          strokeWidth={4}
          strokeLinejoin="round"
        />
      );
      break;
  }
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" style={{overflow: 'visible', display: 'block'}}>
      {body}
    </svg>
  );
};
