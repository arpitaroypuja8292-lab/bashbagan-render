import React from 'react';
import {Composition} from 'remotion';
import {Main} from './Main';
import {FPS, H, W} from './utils';

// অডিও দৈর্ঘ্য ২৮৯.৯০৭ সেকেন্ড → ৮৬৯৮ ফ্রেম @30fps
export const Root: React.FC = () => (
  <Composition id="Bashbagan" component={Main} durationInFrames={Math.ceil(289.907 * FPS)} fps={FPS} width={W} height={H} />
);
