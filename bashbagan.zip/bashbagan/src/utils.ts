import {spring} from 'remotion';

export const FPS = 30;
export const W = 1920;
export const H = 1080;

export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k;

/** spring pop-in starting at startSec (0 before start) */
export const pop = (frame: number, startSec: number, damping = 12, stiffness = 150) => {
  const f = frame - startSec * FPS;
  if (f < 0) return 0;
  return spring({frame: f, fps: FPS, config: {damping, stiffness, mass: 0.7}});
};

/** 0→1 fade in over d sec after a, 1→0 fade out over d sec before b */
export const fadeWin = (t: number, a: number, b: number, d = 0.25) =>
  clamp((t - a) / d, 0, 1) * clamp((b - t) / d, 0, 1);

export type TL<T> = T | Array<[number, T]>;
/** timeline lookup: either constant, or list of [startSec, value] */
export const tl = <T>(v: TL<T> | undefined, t: number, def: T): T => {
  if (v === undefined) return def;
  if (!Array.isArray(v)) return v as T;
  let cur = def;
  for (const [s, val] of v as Array<[number, T]>) if (t >= s) cur = val;
  return cur;
};

export const jitter = (frame: number, amp: number) => ({
  x: Math.sin(frame * 12.9898) * amp,
  y: Math.cos(frame * 78.233) * amp,
});

export const rnd = (i: number, seed = 0) => {
  const v = Math.sin(i * 127.1 + seed * 311.7) * 43758.5453;
  return v - Math.floor(v);
};
