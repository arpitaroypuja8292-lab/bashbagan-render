import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';
import {SceneView} from './Scene';
import {scenes} from './story';
import {FPS, clamp} from './utils';

const {fontFamily} = loadFont('normal', {weights: ['500', '700'], subsets: ['bengali', 'latin']});

export const Main: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  return (
    <AbsoluteFill style={{background: '#000', fontFamily}}>
      <Audio src={staticFile('voice.mp3')} volume={1} />
      {scenes.map((sc) => (t >= sc.a && t < sc.b + 0.3 ? <SceneView key={sc.id} sc={sc} /> : null))}
      <AbsoluteFill style={{background: '#000', opacity: clamp((t - 288.9) / 1.0, 0, 1)}} />
    </AbsoluteFill>
  );
};
