import React from 'react';
import {useCurrentFrame} from 'remotion';
import {clamp, fadeWin, FPS, pop, W} from './utils';
import {Icon, IconType} from './Icons';

export const FONT = "'Hind Siliguri', sans-serif";
const O = '#222222';

/* ---------- Speech bubble ---------- */
export const Bubble: React.FC<{
  text: string;
  ax: number; // x of speaker head
  ay: number; // y of top of speaker head
  a: number;
  b: number;
  color?: string;
}> = ({text, ax, ay, a, b, color = '#fffaf0'}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const p = pop(frame, a, 13, 170);
  const out = clamp((b - t) / 0.18, 0, 1);
  const w = Math.min(880, Math.max(300, text.length * 27 + 100));
  const left = clamp(ax - w / 2, 40, W - 40 - w);
  const tailX = clamp(ax - left, 56, w - 56);
  return (
    <div
      style={{
        position: 'absolute',
        left,
        bottom: 1080 - (ay - 34),
        width: w,
        transform: `scale(${0.6 + 0.4 * p})`,
        transformOrigin: `${tailX}px 100%`,
        opacity: Math.min(1, p * 1.4) * out,
      }}
    >
      <div
        style={{
          background: color,
          border: `3px solid ${O}`,
          borderRadius: 34,
          padding: '18px 30px 20px',
          fontFamily: FONT,
          fontSize: 44,
          fontWeight: 700,
          lineHeight: 1.35,
          color: O,
          textAlign: 'center',
          boxShadow: '0 8px 22px rgba(0,0,0,0.35)',
        }}
      >
        {text}
      </div>
      <svg width={48} height={36} viewBox="0 0 48 36" style={{position: 'absolute', left: tailX - 24, top: '100%', marginTop: -3, overflow: 'visible'}}>
        <path d="M4 -2 L24 34 L44 -2" fill={color} stroke={O} strokeWidth={3} strokeLinejoin="round" />
        <rect x={5} y={-6} width={38} height={8} fill={color} />
      </svg>
    </div>
  );
};

/* ---------- Stamp ---------- */
export const Stamp: React.FC<{
  text: string;
  x: number;
  y: number;
  rot?: number;
  color?: string;
  size?: number;
  a: number;
  b: number;
}> = ({text, x, y, rot = -5, color = '#e8554e', size = 96, a, b}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const p = pop(frame, a, 9, 220);
  const out = clamp((b - t) / 0.25, 0, 1);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${1 + (1 - p) * 1.2})`,
        opacity: clamp(p * 1.5, 0, 1) * out,
        fontFamily: FONT,
        fontSize: size,
        fontWeight: 700,
        color,
        border: `10px solid ${color}`,
        borderRadius: 22,
        padding: '4px 40px 10px',
        background: 'rgba(10,14,20,0.55)',
        whiteSpace: 'nowrap',
        textShadow: '0 4px 14px rgba(0,0,0,0.5)',
      }}
    >
      {text}
    </div>
  );
};

/* ---------- Name badge ---------- */
export const NameBadge: React.FC<{text: string; x: number; y: number; color: string; a: number; b: number}> = ({
  text,
  x,
  y,
  color,
  a,
  b,
}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const p = pop(frame, a, 12, 180);
  const out = clamp((b - t) / 0.25, 0, 1);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,0) scale(${p})`,
        opacity: out,
        background: color,
        border: `3px solid ${O}`,
        borderRadius: 999,
        padding: '2px 34px 6px',
        fontFamily: FONT,
        fontSize: 40,
        fontWeight: 700,
        color: '#fff',
        whiteSpace: 'nowrap',
        boxShadow: '0 6px 16px rgba(0,0,0,0.4)',
      }}
    >
      {text}
    </div>
  );
};

/* ---------- Place / time pill ---------- */
export const PlacePill: React.FC<{text: string; a: number}> = ({text, a}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const p = pop(frame, a, 14, 120);
  const out = clamp((a + 4.2 - t) / 0.4, 0, 1);
  return (
    <div
      style={{
        position: 'absolute',
        left: 56,
        top: 44,
        transform: `translateX(${(1 - p) * -380}px)`,
        opacity: out,
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        background: 'rgba(12,18,26,0.72)',
        border: '2px solid rgba(255,255,255,0.55)',
        borderRadius: 999,
        padding: '6px 30px 10px 22px',
        fontFamily: FONT,
        fontSize: 40,
        fontWeight: 700,
        color: '#fff',
      }}
    >
      <svg width={26} height={36} viewBox="0 0 26 36">
        <path d="M13 1 C5 1 1 7 1 13 C1 22 13 35 13 35 C13 35 25 22 25 13 C25 7 21 1 13 1Z" fill="#f2c230" stroke={O} strokeWidth={2} />
        <circle cx={13} cy={13} r={5} fill={O} />
      </svg>
      {text}
    </div>
  );
};

/* ---------- Popping icon ---------- */
export const IconPop: React.FC<{type: IconType; x: number; y: number; size?: number; a: number; b: number}> = ({
  type,
  x,
  y,
  size = 140,
  a,
  b,
}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const p = pop(frame, a, 10, 200);
  const out = clamp((b - t) / 0.25, 0, 1);
  const pulse = 1 + Math.sin(frame / 6) * 0.06;
  const fy = Math.sin(frame / 12) * 10;
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y + fy,
        transform: `translate(-50%,-50%) scale(${p * pulse})`,
        opacity: out,
        filter: 'drop-shadow(0 8px 14px rgba(0,0,0,0.45))',
      }}
    >
      <Icon type={type} size={size} frame={frame} />
    </div>
  );
};

/* ---------- Selective caption ---------- */
const KEY = [
  'শ্যামপুর',
  'বাঁশবাগান',
  'বারোটা',
  'মায়া',
  'বটগাছ',
  'নূপুর',
  'কান্না',
  'নিখোঁজ',
  'আত্মা',
  'শিকার',
  'কঙ্কাল',
  'নিতাই',
  'হরিপদ',
  'রতন',
  'ঝুম',
  'ঠক',
  'মারা',
  'প্রতিশোধ',
  'আতঙ্ক',
  'জীবিত',
  'নীরবতা',
  'অজ্ঞান',
  'অদ্ভুত',
];

export const chunkText = (text: string, a: number, b: number) => {
  const words = text.split(/\s+/).filter(Boolean);
  const groups: string[][] = [];
  for (let i = 0; i < words.length; i += 5) groups.push(words.slice(i, i + 5));
  if (groups.length > 1 && groups[groups.length - 1].length < 2) {
    const last = groups.pop()!;
    groups[groups.length - 1].push(...last);
  }
  const lens = groups.map((g) => g.join(' ').length + 2);
  const total = lens.reduce((x, y) => x + y, 0);
  let cur = a;
  return groups.map((g, i) => {
    const d = ((b - a) * lens[i]) / total;
    const o = {words: g, a: cur, b: cur + d};
    cur += d;
    return o;
  });
};

export const Caption: React.FC<{text: string; a: number; b: number}> = ({text, a, b}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const chunks = chunkText(text, a, b);
  const idx = chunks.findIndex((c) => t >= c.a && t < c.b);
  if (idx < 0) return null;
  const c = chunks[idx];
  const p = pop(frame, c.a, 14, 200);
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        width: W,
        bottom: 42,
        display: 'flex',
        justifyContent: 'center',
        opacity: clamp(p * 1.6, 0, 1),
        transform: `translateY(${(1 - p) * 26}px)`,
      }}
    >
      <div
        style={{
          fontFamily: FONT,
          fontSize: 56,
          fontWeight: 700,
          color: '#fff',
          whiteSpace: 'nowrap',
          padding: '4px 36px 10px',
          borderRadius: 24,
          background: 'rgba(8,12,18,0.42)',
          textShadow: '0 3px 10px rgba(0,0,0,0.9), 0 0 3px rgba(0,0,0,0.9)',
        }}
      >
        {c.words.map((w, i) => {
          const hit = KEY.some((k) => w.includes(k));
          return (
            <span key={i} style={{color: hit ? '#ffd23f' : '#fff'}}>
              {w}
              {i < c.words.length - 1 ? ' ' : ''}
            </span>
          );
        })}
      </div>
    </div>
  );
};

export {fadeWin};
