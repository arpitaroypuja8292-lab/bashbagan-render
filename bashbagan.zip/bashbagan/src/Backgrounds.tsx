import React from 'react';
import {useCurrentFrame} from 'remotion';
import {FPS, W, H, rnd, pop, clamp} from './utils';

export type BgCfg =
  | {k: 'clean'}
  | {k: 'bamboo'}
  | {k: 'banyan'; skeletonAt: number}
  | {k: 'tea'}
  | {k: 'home'; v: 'window' | 'door'; ghostAt?: number; knocks?: number[]};

const O = '#222222';

const NightSky: React.FC<{top?: string; bottom?: string; moon?: boolean; mx?: number; my?: number}> = ({
  top = '#0a111d',
  bottom = '#34485e',
  moon = true,
  mx = 1560,
  my = 170,
}) => (
  <g>
    <defs>
      <linearGradient id="nsky" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={top} />
        <stop offset="1" stopColor={bottom} />
      </linearGradient>
      <radialGradient id="moonGlow">
        <stop offset="0" stopColor="#dfe8f2" stopOpacity={0.55} />
        <stop offset="1" stopColor="#dfe8f2" stopOpacity={0} />
      </radialGradient>
    </defs>
    <rect width={W} height={H} fill="url(#nsky)" />
    {moon && (
      <g>
        <circle cx={mx} cy={my} r={260} fill="url(#moonGlow)" />
        <circle cx={mx} cy={my} r={74} fill="#eef2f6" />
        <circle cx={mx - 22} cy={my - 10} r={14} fill="#d5dce4" />
        <circle cx={mx + 24} cy={my + 22} r={10} fill="#d5dce4" />
      </g>
    )}
  </g>
);

export const Fog: React.FC<{y?: number; opacity?: number; tone?: string}> = ({y = 760, opacity = 0.5, tone = '170,195,215'}) => {
  const frame = useCurrentFrame();
  return (
    <g>
      <defs>
        <radialGradient id="fogG">
          <stop offset="0" stopColor={`rgb(${tone})`} stopOpacity={opacity} />
          <stop offset="1" stopColor={`rgb(${tone})`} stopOpacity={0} />
        </radialGradient>
      </defs>
      {[0, 1, 2, 3, 4].map((i) => {
        const dx = Math.sin(frame / (140 + i * 30) + i * 2) * 140;
        return (
          <ellipse
            key={i}
            cx={i * 480 - 100 + dx}
            cy={y + (i % 2) * 70 + Math.sin(frame / 90 + i) * 12}
            rx={520}
            ry={120}
            fill="url(#fogG)"
          />
        );
      })}
    </g>
  );
};

const Stalks: React.FC<{
  n: number;
  y0: number;
  y1: number;
  wMin: number;
  wMax: number;
  col: string;
  node: string;
  seed: number;
  sway?: number;
}> = ({n, y0, y1, wMin, wMax, col, node, seed, sway = 6}) => {
  const frame = useCurrentFrame();
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const x = ((i + rnd(i, seed) * 0.8) * W) / n;
        const w = wMin + rnd(i + 40, seed) * (wMax - wMin);
        const lean = (rnd(i + 80, seed) - 0.5) * 120 + Math.sin(frame / 70 + i) * sway;
        const nodes = 6;
        return (
          <g key={i}>
            <path d={`M${x - w / 2} ${y0} L${x + lean - w / 2} ${y1} L${x + lean + w / 2} ${y1} L${x + w / 2} ${y0}Z`} fill={col} />
            {Array.from({length: nodes}).map((_, k) => {
              const f = (k + 1) / (nodes + 1);
              const nx = x + lean * f;
              const ny = y0 + (y1 - y0) * f;
              return <path key={k} d={`M${nx - w / 2 - 3} ${ny} h${w + 6}`} stroke={node} strokeWidth={4} />;
            })}
            {[0.55, 0.72, 0.86].map((f, k) => {
              const nx = x + lean * f;
              const ny = y0 + (y1 - y0) * f;
              const dir = k % 2 ? 1 : -1;
              return (
                <ellipse
                  key={k}
                  cx={nx + dir * 46}
                  cy={ny}
                  rx={52}
                  ry={8}
                  fill={col}
                  transform={`rotate(${dir * -18 + Math.sin(frame / 40 + i + k) * 4} ${nx} ${ny})`}
                />
              );
            })}
          </g>
        );
      })}
    </g>
  );
};

const Vig: React.FC<{o?: number}> = ({o = 0.5}) => (
  <g>
    <defs>
      <radialGradient id="vigG" cx="0.5" cy="0.5" r="0.75">
        <stop offset="0.55" stopColor="#000" stopOpacity={0} />
        <stop offset="1" stopColor="#000" stopOpacity={o} />
      </radialGradient>
    </defs>
    <rect width={W} height={H} fill="url(#vigG)" />
  </g>
);

const Bamboo: React.FC = () => (
  <g>
    <NightSky />
    <Stalks n={26} y0={700} y1={-40} wMin={14} wMax={22} col="#1c2b33" node="#141f25" seed={1} sway={3} />
    <rect y={720} width={W} height={H - 720} fill="#18222a" />
    <path d="M760 1080 C800 900 880 800 930 722 L1010 722 C1040 800 1180 920 1360 1080Z" fill="#2b3640" />
    <Stalks n={13} y0={900} y1={-60} wMin={28} wMax={40} col="#26443f" node="#193230" seed={2} sway={5} />
    <Fog y={800} opacity={0.45} />
    <Stalks n={5} y0={1120} y1={-80} wMin={64} wMax={84} col="#142724" node="#0d1b19" seed={3} sway={8} />
    <Vig />
  </g>
);

const Banyan: React.FC<{skeletonAt: number}> = ({skeletonAt}) => {
  const frame = useCurrentFrame();
  const cx = 1350;
  const sk = pop(frame, skeletonAt, 14, 90);
  return (
    <g>
      <NightSky mx={520} my={150} />
      <Stalks n={18} y0={740} y1={200} wMin={14} wMax={20} col="#18262d" node="#121c21" seed={5} sway={2} />
      <rect y={800} width={W} height={H - 800} fill="#161f26" />
      {/* trunk */}
      <path
        d={`M${cx - 230} 1080 C${cx - 170} 820 ${cx - 120} 600 ${cx - 90} 300 L${cx + 90} 300 C${cx + 120} 600 ${cx + 170} 820 ${cx + 250} 1080Z`}
        fill="#2b2420"
      />
      {[-120, -60, 0, 60, 120].map((d) => (
        <path key={d} d={`M${cx + d * 0.6} 330 C${cx + d} 560 ${cx + d * 1.2} 800 ${cx + d * 1.5} 1060`} fill="none" stroke="#1d1814" strokeWidth={8} />
      ))}
      {/* canopy */}
      {[
        [cx - 280, 170, 360, 150],
        [cx, 90, 440, 160],
        [cx + 320, 190, 340, 140],
        [cx - 80, 250, 320, 110],
        [cx + 140, 260, 300, 100],
      ].map(([x, y, rx, ry], i) => (
        <ellipse key={i} cx={x} cy={y} rx={rx} ry={ry} fill={i % 2 ? '#13221d' : '#0f1c18'} />
      ))}
      {/* hanging roots */}
      {Array.from({length: 22}).map((_, i) => {
        const x = cx - 560 + i * 54 + rnd(i, 9) * 30;
        const len = 220 + rnd(i, 4) * 420;
        const sw = Math.sin(frame / 50 + i) * 8;
        return (
          <path
            key={i}
            d={`M${x} 250 Q${x + sw} ${250 + len / 2} ${x + sw * 1.6} ${250 + len}`}
            fill="none"
            stroke="#2b2420"
            strokeWidth={5 + rnd(i, 6) * 7}
            strokeLinecap="round"
          />
        );
      })}
      <Fog y={900} opacity={0.4} />
      {/* skeleton */}
      <g opacity={sk} transform={`translate(0,${(1 - sk) * 50})`}>
        <ellipse cx={330} cy={1000} rx={250} ry={36} fill="#0b1015" opacity={0.7} />
        <g stroke="#e8e3d3" strokeWidth={9} strokeLinecap="round" fill="none">
          <path d="M290 975 L560 990" />
          {[0, 1, 2, 3].map((i) => (
            <path key={i} d={`M${380 + i * 40} 984 C${390 + i * 40} 940 ${430 + i * 40} 938 ${446 + i * 40} 970`} />
          ))}
          <path d="M470 1000 L610 1030 M470 1000 L620 1010" />
        </g>
        <circle cx={250} cy={968} r={42} fill="#f1ecdc" stroke={O} strokeWidth={3} />
        <ellipse cx={236} cy={962} rx={9} ry={11} fill={O} />
        <ellipse cx={266} cy={962} rx={9} ry={11} fill={O} />
        <path d="M244 984 h16 M248 984 v12 M256 984 v12" stroke={O} strokeWidth={3} />
        <ellipse cx={640} cy={1040} rx={34} ry={12} fill="none" stroke="#c49a2c" strokeWidth={8} />
        {[620, 640, 660].map((x) => (
          <circle key={x} cx={x} cy={1056} r={6} fill="#e2b84a" stroke={O} strokeWidth={2} />
        ))}
      </g>
      <Vig o={0.55} />
    </g>
  );
};

const Tea: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <g>
      <defs>
        <linearGradient id="dusk" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#8f8a9a" />
          <stop offset="0.6" stopColor="#e2a96e" />
          <stop offset="1" stopColor="#f0c78a" />
        </linearGradient>
        <radialGradient id="sunG">
          <stop offset="0" stopColor="#ffe2a8" stopOpacity={0.9} />
          <stop offset="1" stopColor="#ffe2a8" stopOpacity={0} />
        </radialGradient>
      </defs>
      <rect width={W} height={H} fill="url(#dusk)" />
      <circle cx={1500} cy={560} r={300} fill="url(#sunG)" />
      <circle cx={1500} cy={560} r={86} fill="#ffe7b8" />
      {/* far huts + trees */}
      {[1100, 1280, 1700].map((x, i) => (
        <g key={x} opacity={0.55}>
          <rect x={x} y={640} width={120} height={80} fill="#6b5a4a" />
          <path d={`M${x - 14} 646 L${x + 60} 590 L${x + 134} 646Z`} fill="#7d6840" />
          <circle cx={x + 190 + i * 10} cy={600} r={60} fill="#4f5b3f" />
          <rect x={x + 184 + i * 10} y={640} width={12} height={80} fill="#4a3a2a" />
        </g>
      ))}
      <rect y={760} width={W} height={H - 760} fill="#6a5640" />
      <rect y={760} width={W} height={26} fill="#5a4833" />
      {/* shop */}
      <rect x={90} y={400} width={760} height={380} fill="#7a5a3a" />
      {Array.from({length: 18}).map((_, i) => (
        <path key={i} d={`M${90 + i * 42} 400 V780`} stroke="#5f442a" strokeWidth={3} />
      ))}
      <path d="M30 420 L470 230 L910 420Z" fill="#a1803f" stroke={O} strokeWidth={3} strokeLinejoin="round" />
      {Array.from({length: 14}).map((_, i) => (
        <path key={i} d={`M${470 + (i - 7) * 18} 250 L${470 + (i - 7) * 62} 420`} stroke="#80632c" strokeWidth={4} />
      ))}
      <rect x={380} y={300} width={180} height={80} rx={14} fill="#2a2018" stroke={O} strokeWidth={3} />
      <text x={470} y={360} textAnchor="middle" fontSize={64} fontWeight={700} fill="#ffe7a0" fontFamily="Hind Siliguri, sans-serif">
        চা
      </text>
      <rect x={96} y={420} width={22} height={360} fill="#5a3f28" />
      <rect x={822} y={420} width={22} height={360} fill="#5a3f28" />
      <rect x={110} y={690} width={720} height={90} fill="#5a3f28" stroke={O} strokeWidth={3} />
      <rect x={110} y={680} width={720} height={16} fill="#8a6a46" stroke={O} strokeWidth={3} />
      {/* clay stove + kettle */}
      <path d="M520 680 L530 610 H650 L660 680Z" fill="#8c4b32" stroke={O} strokeWidth={3} />
      <ellipse cx={590} cy={585} rx={62} ry={40} fill="#b9bcc0" stroke={O} strokeWidth={3} />
      <path d="M648 575 L700 540 L704 548 L654 592Z" fill="#b9bcc0" stroke={O} strokeWidth={3} />
      <path d="M545 560 Q590 520 635 560" fill="none" stroke={O} strokeWidth={5} />
      {[0, 1, 2].map((i) => {
        const ph = ((frame + i * 20) % 60) / 60;
        return (
          <path
            key={i}
            d={`M${700 + i * 6} ${540 - ph * 90} q-14 -20 0 -40 q14 -20 0 -40`}
            fill="none"
            stroke="#fff"
            strokeWidth={6}
            strokeLinecap="round"
            opacity={(1 - ph) * 0.7}
          />
        );
      })}
      {[150, 190, 230].map((x) => (
        <rect key={x} x={x} y={652} width={22} height={30} rx={4} fill="#e8f1f4" opacity={0.85} stroke={O} strokeWidth={2} />
      ))}
      {/* bamboo bench */}
      <g>
        <rect x={1360} y={800} width={460} height={30} rx={8} fill="#b18a4e" stroke={O} strokeWidth={3} />
        {[1380, 1480, 1700, 1790].map((x) => (
          <rect key={x} x={x} y={826} width={18} height={110} rx={6} fill="#8b6a38" stroke={O} strokeWidth={3} />
        ))}
        {Array.from({length: 6}).map((_, i) => (
          <path key={i} d={`M${1390 + i * 76} 802 V828`} stroke="#8b6a38" strokeWidth={3} />
        ))}
      </g>
      <Vig o={0.35} />
    </g>
  );
};

const Home: React.FC<{v: 'window' | 'door'; ghostAt?: number; knocks?: number[]}> = ({v, ghostAt, knocks = []}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const flick = 0.85 + Math.sin(frame * 0.6) * 0.08 + Math.sin(frame * 1.7) * 0.06;
  const gp = ghostAt !== undefined ? pop(frame, ghostAt, 16, 60) : 0;
  const kn = knocks.reduce((m, k) => (t >= k && t < k + 0.2 ? 6 : m), 0);
  const dj = kn ? Math.sin(frame * 3.1) * kn : 0;
  return (
    <g>
      <defs>
        <radialGradient id="lampG">
          <stop offset="0" stopColor="#ffcf72" stopOpacity={0.6} />
          <stop offset="1" stopColor="#ffcf72" stopOpacity={0} />
        </radialGradient>
        <linearGradient id="outsideG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0d1624" />
          <stop offset="1" stopColor="#3b516a" />
        </linearGradient>
      </defs>
      <rect width={W} height={H} fill="#37424b" />
      {Array.from({length: 48}).map((_, i) => (
        <path key={i} d={`M${i * 40} 0 V840`} stroke="#2d383f" strokeWidth={8} />
      ))}
      <rect width={W} height={90} fill="#1d1712" />
      <rect y={840} width={W} height={H - 840} fill="#2b2118" />
      <rect y={832} width={W} height={14} fill="#1a130d" />
      {v === 'window' ? (
        <g>
          <rect x={1260} y={170} width={460} height={450} fill="#5a3d25" stroke={O} strokeWidth={4} />
          <rect x={1290} y={200} width={400} height={390} fill="url(#outsideG)" />
          <circle cx={1580} cy={290} r={34} fill="#e8eef4" />
          <g transform={`translate(1490,${520 + (1 - gp) * 40})`} opacity={gp}>
            <path d="M-46 80 C-40 -20 40 -20 46 80Z" fill="#f2f2f2" />
            <circle cx={0} cy={-40} r={26} fill="#e8eef2" />
            <path d="M-30 -48 C-34 -80 34 -80 30 -48 C26 -20 24 20 20 60 L-20 60 C-26 20 -30 -20 -30 -48Z" fill="#0d0d0d" />
            <ellipse cx={6} cy={-34} rx={5} ry={7} fill="#000" />
            <ellipse cx={-10} cy={-34} rx={5} ry={7} fill="#000" />
          </g>
          <Fog y={560} opacity={0.35} />
          <rect x={1290} y={200} width={400} height={390} fill="none" />
          <path d="M1490 200 V590 M1290 395 H1690" stroke="#5a3d25" strokeWidth={14} />
          <rect x={1260} y={170} width={460} height={450} fill="none" stroke="#3d2916" strokeWidth={12} />
          <rect x={1240} y={620} width={500} height={24} fill="#4a3320" stroke={O} strokeWidth={3} />
        </g>
      ) : (
        <g transform={`translate(${dj},0)`}>
          <rect x={1180} y={150} width={500} height={700} fill="#4d3321" stroke={O} strokeWidth={4} />
          {Array.from({length: 6}).map((_, i) => (
            <path key={i} d={`M${1180 + i * 83} 150 V850`} stroke="#3a2616" strokeWidth={5} />
          ))}
          <rect x={1180} y={300} width={500} height={26} fill="#3a2616" />
          <rect x={1180} y={640} width={500} height={26} fill="#3a2616" />
          <circle cx={1220} cy={500} r={14} fill="#c9a24a" stroke={O} strokeWidth={3} />
          <ellipse cx={1430} cy={856} rx={240} ry={20} fill="#9cc3ff" opacity={0.28} />
          <rect x={1160} y={130} width={540} height={30} fill="#2a1b0f" />
        </g>
      )}
      {/* table with lantern */}
      <rect x={120} y={760} width={400} height={26} fill="#5a3f28" stroke={O} strokeWidth={3} />
      {[140, 480].map((x) => (
        <rect key={x} x={x} y={784} width={20} height={150} fill="#4a3320" stroke={O} strokeWidth={3} />
      ))}
      <circle cx={320} cy={690} r={300} fill="url(#lampG)" opacity={flick} />
      <rect x={298} y={700} width={44} height={60} rx={8} fill="#ffd36a" stroke={O} strokeWidth={3} />
      <rect x={306} y={710} width={28} height={40} rx={4} fill="#fff0b0" />
      <path d="M302 702 Q320 672 338 702" fill="none" stroke={O} strokeWidth={4} />
      <Vig o={0.5} />
    </g>
  );
};

const Clean: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <g>
      <defs>
        <radialGradient id="cleanG" cx="0.5" cy="0.45" r="0.8">
          <stop offset="0" stopColor="#223244" />
          <stop offset="1" stopColor="#0a1018" />
        </radialGradient>
      </defs>
      <rect width={W} height={H} fill="url(#cleanG)" />
      <circle cx={1650} cy={170} r={64} fill="#e9eef3" opacity={0.85} />
      <circle cx={1650} cy={170} r={200} fill="url(#moonGlow2)" />
      <defs>
        <radialGradient id="moonGlow2">
          <stop offset="0" stopColor="#dfe8f2" stopOpacity={0.3} />
          <stop offset="1" stopColor="#dfe8f2" stopOpacity={0} />
        </radialGradient>
      </defs>
      {Array.from({length: 26}).map((_, i) => {
        const x = (rnd(i, 3) * W + frame * (0.2 + rnd(i, 4) * 0.5)) % W;
        const y = (rnd(i, 5) * H - frame * (0.15 + rnd(i, 6) * 0.4) + H * 3) % H;
        return <circle key={i} cx={x} cy={y} r={2 + rnd(i, 7) * 3} fill="#aac3dc" opacity={0.25 + rnd(i, 8) * 0.3} />;
      })}
      <Fog y={900} opacity={0.3} />
      <Vig o={0.6} />
    </g>
  );
};

export const Background: React.FC<{cfg: BgCfg}> = ({cfg}) => {
  let inner: React.ReactNode;
  switch (cfg.k) {
    case 'bamboo':
      inner = <Bamboo />;
      break;
    case 'banyan':
      inner = <Banyan skeletonAt={cfg.skeletonAt} />;
      break;
    case 'tea':
      inner = <Tea />;
      break;
    case 'home':
      inner = <Home v={cfg.v} ghostAt={cfg.ghostAt} knocks={cfg.knocks} />;
      break;
    default:
      inner = <Clean />;
  }
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0, display: 'block'}}>
      {inner}
    </svg>
  );
};

export {clamp};
