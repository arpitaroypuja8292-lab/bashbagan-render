import type {CharId, Emo, Pose} from './Character';
import type {BgCfg} from './Backgrounds';
import type {CardCfg} from './Cards';
import type {IconType} from './Icons';
import type {TL} from './utils';

export type Who = 'N' | CharId;
export type Cue = {s: number; e: number; who: Who; t: string};

const c = (s: number, e: number, who: Who, t: string): Cue => ({s, e, who, t});

// টেক্সট: মূল স্ক্রিপ্ট থেকে | টাইমিং: SRT/অডিও থেকে
export const cues: Cue[] = [
  c(0.4, 4.5, 'N', 'বাংলার এক প্রত্যন্ত গ্রাম, নাম শ্যামপুর।'),
  c(4.8, 10.2, 'N', 'গ্রামের শেষ প্রান্তের বাঁশবাগান নিয়ে মানুষের মনে ছিল গভীর আতঙ্ক।'),
  c(10.6, 16.5, 'N', 'রাত বারোটার পর ওই বাঁশবাগানে গেলে কেউ আর জীবিত ফিরে আসে না।'),
  c(17.0, 22.8, 'N', 'বিশ বছর আগে গ্রামে বিয়ে হয়ে এসেছিল মায়া নামে এক মেয়ে।'),
  c(23.2, 28.5, 'N', 'বিয়ের সাত দিনের মাথায় সে রহস্যজনকভাবে নিখোঁজ হয়ে যায়।'),
  c(29.0, 34.2, 'N', 'তারপর থেকে মাঝরাতে শোনা যেত এক মহিলার কান্না।'),
  c(34.8, 40.5, 'nitai', 'ও রতন, আজ রাতে ওই বাঁশবাগানের রাস্তা দিয়ে যাস না বাবা।'),
  c(41.0, 45.8, 'ratan', 'কেন কাকা? আবার ভূতের গল্প শুরু করলে নাকি?'),
  c(46.2, 52.8, 'nitai', 'সব গল্প মিথ্যে হয় না রে। ওই বাঁশবাগানে আজও মায়ার আত্মা ঘুরে বেড়ায়।'),
  c(53.2, 58.5, 'ratan', 'আমি এসব ভূত-টুত বিশ্বাস করি না। মানুষ মরলে সব শেষ।'),
  c(59.0, 64.8, 'nitai', 'একদিন তুই নিজেই বুঝবি। তবে সেদিন যেন অনেক দেরি না হয়ে যায়!'),
  c(65.5, 73.2, 'payel', 'শোনো, আজ একটু তাড়াতাড়ি ফিরো। কয়েকদিন ধরে রাত হলেই পুকুরের দিক থেকে একটা মেয়ের কান্নার শব্দ শুনছি।'),
  c(73.6, 78.8, 'ratan', 'আরে, ওসব শেয়ালের শব্দ হবে। তুমি অকারণে ভয় পাচ্ছ।'),
  c(79.2, 86.5, 'payel', 'না গো, নিজের কানে শুনেছি। কাল রাতে জানালার পাশে সাদা শাড়ি পরা একটা মেয়েকেও দেখেছি।'),
  c(87.0, 91.8, 'ratan', 'আচ্ছা ঠিক আছে। তুমি দরজা বন্ধ করে ঘুমিয়ে পড়ো।'),
  c(92.4, 100.5, 'N', 'ঘড়িতে তখন ঠিক রাত বারোটা। বাঁশবাগানের রাস্তা দিয়ে হাঁটতে হাঁটতে হঠাৎ রতন শুনতে পেল—'),
  c(100.8, 104.5, 'N', 'ঝুম... ঝুম... ঝুম...'),
  c(104.8, 107.5, 'ratan', 'কে? কে ওখানে?'),
  c(107.8, 115.2, 'N', 'কোনো উত্তর এল না। সাদা শাড়ি পরা এক মেয়ে দাঁড়িয়ে ছিল, লম্বা কালো চুলে মুখ ঢাকা।'),
  c(115.6, 121.5, 'maya', 'ও দাদা... একটু বাড়ি পৌঁছে দেবেন? আমি রাস্তা হারিয়ে ফেলেছি।'),
  c(121.9, 124.5, 'ratan', 'তোমার বাড়ি কোথায়?'),
  c(124.5, 127.2, 'maya', 'ওই তো... বাঁশবাগানের ভিতরে।'),
  c(127.6, 133.2, 'ratan', 'এই গভীর রাতে তুমি এখানে কী করছ? তুমি... তুমি মানুষ তো?'),
  c(133.6, 138.8, 'maya', 'আমাকে চিনতে পারলে না রতনদা? আমি মায়া!'),
  c(139.2, 144.2, 'ratan', 'মায়া! কিন্তু তুমি তো বিশ বছর আগে মারা গিয়েছিলে!'),
  c(144.6, 149.2, 'maya', 'হ্যাঁ... আর আমাকে মেরেছিল তোমার বাবা!'),
  c(149.6, 154.2, 'ratan', 'না! আমার বাবা কখনো কাউকে খুন করতে পারে না!'),
  c(154.6, 161.8, 'maya', 'তোমার বাবা আমাকে এই বটগাছের নিচে পুঁতে রেখেছিল। আর তাকে সাহায্য করেছিল তোমাদের নিতাই কাকা!'),
  c(162.2, 166.8, 'haripada', 'রতন! পালা বাবা! ওর কথা শুনিস না!'),
  c(167.2, 171.8, 'ratan', 'বাবা! মায়া যা বলছে, সেগুলো কি সত্যি?'),
  c(172.2, 179.8, 'haripada', 'হ্যাঁ বাবা... সব সত্যি। রাগের মাথায় আমি মায়াকে মেরে ফেলেছিলাম। নিতাই আমাকে সাহায্য করেছিল।'),
  c(180.2, 184.5, 'ratan', 'ছিঃ বাবা! তুমি এত বড় পাপ করেছ?'),
  c(184.9, 191.5, 'haripada', 'আমি এত বছর এই পাপের শাস্তি পাচ্ছি। কিন্তু আজ ও আমাকে ছাড়বে না!'),
  c(191.9, 197.5, 'maya', 'আজ আর কেউ বাঁচবে না! আজ আমার প্রতিশোধের রাত!'),
  c(198.0, 203.8, 'N', 'হঠাৎ বাতাস থেমে গেল। লণ্ঠনের আলো কাঁপতে কাঁপতে নিভে গেল।'),
  c(204.2, 209.5, 'haripada', 'মায়া! আমাকে ক্ষমা করে দে! আমি ভুল করেছি!'),
  c(209.9, 216.5, 'maya', 'যখন আমি বাঁচার জন্য কেঁদেছিলাম, তখন তোমার দয়া হয়নি। আজ ক্ষমা চাইছ?'),
  c(217.0, 221.5, 'N', 'তারপর চারদিকে নীরবতা।'),
  c(222.0, 227.5, 'payel', 'ও রতন! তুমি এখানে পড়ে আছ কেন? ওঠো! কী হয়েছে তোমার?'),
  c(228.0, 238.5, 'N', 'রতন অজ্ঞান, হরিপদ কোথাও নেই। একটু দূরে মাটির নিচ থেকে বেরিয়ে ছিল একটি কঙ্কাল আর একটি মরচে ধরা সোনার নূপুর।'),
  c(239.0, 246.8, 'N', 'নিতাই কাকাকেও আর খুঁজে পাওয়া যায়নি। সেদিন রাতে রতনের ঘুম ভাঙল এক অদ্ভুত শব্দে—'),
  c(247.2, 250.5, 'N', 'ঝুম... ঝুম... ঝুম...'),
  c(250.9, 257.8, 'maya', 'রতনদা... তোমার বাবাকে তো নিয়ে গেলাম। এবার নিতাইয়ের পালা... তারপর তোমার!'),
  c(258.2, 262.5, 'nitai', 'রতন... দরজা খোল বাবা... আমি নিতাই!'),
  c(262.9, 270.5, 'N', 'কিন্তু রতন জানত, নিতাই কাকা তিন দিন আগেই মারা গেছে! তাহলে দরজার বাইরে কে?'),
  c(270.9, 273.2, 'N', 'ঠক! ঠক! ঠক!'),
  c(273.2, 276.2, 'maya', 'দরজা খোলো রতনদা... আমি এসেছি!'),
  c(276.6, 283.2, 'N', 'আজও শ্যামপুরের মানুষ বলে, রাত বারোটার পর বাঁশবাগানের পথে নূপুরের শব্দ শোনা যায়।'),
  c(283.5, 289.8, 'N', 'আর সাদা শাড়ি পরা কোনো মেয়ে যদি তোমাকে বাড়ি পৌঁছে দিতে বলে, মনে রেখো—সে খুঁজছে তার পরবর্তী শিকার।'),
];

export type CharCfg = {
  id: CharId;
  x: number;
  y?: number;
  s?: number;
  flip?: boolean;
  from?: number;
  to?: number;
  emo?: TL<Emo>;
  pose?: TL<Pose>;
  ghost?: boolean;
  lying?: TL<boolean>;
  walk?: TL<boolean>;
  float?: number;
  tremble?: TL<boolean>;
  lit?: TL<boolean>;
  opacity?: number;
  aboveDark?: boolean;
  move?: {a: number; b: number; x1: number};
};

export type SceneCfg = {
  id: string;
  a: number;
  b: number;
  bg: BgCfg;
  chars?: CharCfg[];
  icons?: {type: IconType; x: number; y: number; size?: number; a: number; b: number}[];
  stamps?: {text: string; x: number; y: number; rot?: number; color?: string; size?: number; a: number; b: number}[];
  cards?: CardCfg[];
  badges?: {id: CharId; text: string; color: string; a: number; b: number}[];
  place?: {text: string; a: number};
  shake?: [number, number, number][];
  flash?: number[];
  zoom?: {a: number; b: number; s: number; ox: number; oy: number};
  dark?: [number, number][];
  tint?: string;
};

const FY = 900; // feet line
const SC = 1.3; // character scale

export const scenes: SceneCfg[] = [
  // ১) শ্যামপুর পরিচিতি — মোশন গ্রাফিক্স
  {
    id: 's1',
    a: 0,
    b: 10.6,
    bg: {k: 'bamboo'},
    tint: 'rgba(5,10,18,0.45)',
    cards: [
      {k: 'title', a: 0.4, b: 4.6, title: 'শ্যামপুর', sub: 'বাংলার এক প্রত্যন্ত গ্রাম'},
      {k: 'info', a: 4.8, b: 10.4, icon: 'bamboo', title: 'বাঁশবাগান', sub: 'গভীর আতঙ্ক', color: '#f2c230'},
    ],
  },
  // ২) রাত ১২টা, ২০ বছর আগে, ৭ দিন, কান্না — মোশন গ্রাফিক্স
  {
    id: 's2',
    a: 10.6,
    b: 34.8,
    bg: {k: 'clean'},
    cards: [
      {k: 'clock', a: 10.6, b: 16.6, title: 'রাত ১২টা', sub: 'জীবিত ফেরে না'},
      {k: 'cal', a: 17.0, b: 22.9, big: '২০', label: 'বছর আগে', title: 'মায়ার বিয়ে'},
      {k: 'seven', a: 23.2, b: 28.6, title: 'বিয়ের ৭ দিন পর', stamp: 'নিখোঁজ'},
      {k: 'wave', a: 29.0, b: 34.6, title: 'মাঝরাতের কান্না', sub: 'এক মহিলার কান্না'},
    ],
  },
  // ৩) চায়ের দোকান
  {
    id: 's3',
    a: 34.8,
    b: 65.5,
    bg: {k: 'tea'},
    place: {text: 'চায়ের দোকান · বিকেল', a: 35},
    chars: [
      {
        id: 'nitai',
        x: 700,
        emo: 'sad',
        pose: [
          [34.8, 'point'],
          [40.5, 'idle'],
          [46.2, 'point'],
          [52.8, 'idle'],
          [59.0, 'point'],
          [64.8, 'idle'],
        ],
      },
      {
        id: 'ratan',
        x: 1250,
        flip: true,
        emo: [
          [34.8, 'neutral'],
          [41.0, 'smile'],
          [46.2, 'neutral'],
          [53.2, 'smile'],
          [59.0, 'worry' as Emo],
        ] as TL<Emo>,
        pose: [
          [34.8, 'idle'],
          [53.2, 'hug'],
          [58.6, 'idle'],
        ],
      },
    ],
    badges: [
      {id: 'nitai', text: 'নিতাই কাকা', color: '#7b5ea7', a: 35.2, b: 38.6},
      {id: 'ratan', text: 'রতন', color: '#d9622b', a: 41.2, b: 44.6},
    ],
    icons: [
      {type: 'warning', x: 1000, y: 470, size: 150, a: 35.4, b: 40.3},
      {type: 'question', x: 1530, y: 500, size: 130, a: 41.4, b: 45.6},
      {type: 'ghost', x: 960, y: 480, size: 170, a: 46.6, b: 52.6},
      {type: 'ghostx', x: 1530, y: 500, size: 150, a: 53.6, b: 58.3},
      {type: 'hourglass', x: 1000, y: 470, size: 150, a: 59.4, b: 64.6},
    ],
  },
  // ৪) রতনের বাড়ি
  {
    id: 's4',
    a: 65.5,
    b: 92.4,
    bg: {k: 'home', v: 'window', ghostAt: 82.0},
    place: {text: 'রতনের বাড়ি · সন্ধ্যারাত', a: 66},
    chars: [
      {
        id: 'payel',
        x: 640,
        emo: [
          [65.5, 'fear'],
          [73.6, 'sad'],
          [79.2, 'fear'],
          [87, 'sad'],
        ],
        pose: 'hug',
        tremble: [
          [65.5, true],
          [73.2, false],
          [79.2, true],
          [86.5, false],
        ],
      },
      {
        id: 'ratan',
        x: 1010,
        flip: true,
        emo: [
          [65.5, 'neutral'],
          [73.6, 'smile'],
          [78.9, 'neutral'],
          [87, 'smile'],
        ],
        pose: [
          [65.5, 'idle'],
          [73.6, 'hug'],
          [79, 'idle'],
        ],
      },
    ],
    badges: [{id: 'payel', text: 'পায়েল', color: '#2f8f83', a: 66, b: 69.5}],
    icons: [
      {type: 'wave', x: 1480, y: 770, size: 150, a: 66.5, b: 73.0},
      {type: 'exclaim', x: 1160, y: 330, size: 120, a: 82.2, b: 86.3},
    ],
  },
  // ৫) রাত ১২টা, বাঁশবাগানের পথে
  {
    id: 's5',
    a: 92.4,
    b: 115.2,
    bg: {k: 'bamboo'},
    place: {text: 'বাঁশবাগান · রাত ১২টা', a: 92.8},
    chars: [
      {
        id: 'ratan',
        x: 300,
        move: {a: 92.4, b: 100.5, x1: 820},
        walk: [
          [92.4, true],
          [100.5, false],
        ],
        emo: [
          [92.4, 'neutral'],
          [100.8, 'fear'],
        ],
        tremble: [
          [100.8, true],
        ],
        pose: [
          [92.4, 'idle'],
          [104.8, 'hug'],
        ],
      },
      {id: 'maya', x: 1380, flip: true, from: 107.8, float: 70, emo: 'cold', pose: 'idle'},
    ],
    icons: [
      {type: 'nupur', x: 1250, y: 470, size: 170, a: 100.9, b: 104.4},
      {type: 'wave', x: 1250, y: 300, size: 140, a: 101.2, b: 104.4},
    ],
    shake: [[100.8, 104.5, 2.5]],
    flash: [107.8],
  },
  // ৬) মায়ার আবির্ভাব — বাঁশবাগান
  {
    id: 's6',
    a: 115.2,
    b: 154.4,
    bg: {k: 'bamboo'},
    chars: [
      {
        id: 'ratan',
        x: 820,
        emo: [
          [115.2, 'worry' as Emo],
          [121.9, 'neutral'],
          [127.6, 'fear'],
          [133.6, 'shock'],
          [144.6, 'fear'],
          [149.6, 'angry'],
        ] as TL<Emo>,
        pose: [
          [115.2, 'idle'],
          [133.6, 'cover'],
          [137, 'hug'],
          [149.6, 'idle'],
        ],
        tremble: [
          [133.6, true],
        ],
      },
      {
        id: 'maya',
        x: 1380,
        flip: true,
        float: 70,
        emo: 'cold',
        pose: [
          [115.2, 'idle'],
          [144.6, 'point'],
          [149.4, 'idle'],
        ],
      },
    ],
    badges: [{id: 'maya', text: 'মায়া', color: '#7a8fa6', a: 115.6, b: 119}],
    icons: [
      {type: 'question', x: 1080, y: 520, size: 130, a: 128.0, b: 133.0},
      {type: 'skull', x: 1080, y: 540, size: 130, a: 139.6, b: 144.0},
      {type: 'ghost', x: 1090, y: 540, size: 150, a: 145.0, b: 149.0},
    ],
    shake: [[133.6, 135, 6]],
    flash: [133.6],
    zoom: {a: 133.6, b: 139, s: 1.18, ox: 960, oy: 420},
  },
  // ৭) বটগাছের নিচে সত্য
  {
    id: 's7',
    a: 154.4,
    b: 172,
    bg: {k: 'banyan', skeletonAt: 156.5},
    place: {text: 'প্রাচীন বটগাছ · রাত', a: 154.8},
    chars: [
      {
        id: 'ratan',
        x: 760,
        emo: [
          [154.4, 'shock'],
          [167.2, 'fear'],
        ],
        pose: 'hug',
        tremble: true,
      },
      {
        id: 'maya',
        x: 1130,
        flip: true,
        float: 70,
        emo: 'cold',
        pose: [
          [154.4, 'point'],
          [161.9, 'idle'],
        ],
      },
      {id: 'haripada', x: 1620, flip: true, from: 162.2, emo: 'fear', pose: 'hold', tremble: true},
    ],
    badges: [{id: 'haripada', text: 'হরিপদ', color: '#a0702f', a: 162.4, b: 165.8}],
    icons: [
      {type: 'skull', x: 330, y: 760, size: 150, a: 157.0, b: 161.6},
      {type: 'exclaim', x: 960, y: 520, size: 120, a: 162.4, b: 166.6},
    ],
    shake: [[154.6, 155.6, 5]],
  },
  // ৮) হরিপদর স্বীকারোক্তি
  {
    id: 's8',
    a: 172,
    b: 197.8,
    bg: {k: 'banyan', skeletonAt: 0},
    chars: [
      {
        id: 'ratan',
        x: 600,
        emo: [
          [172, 'shock'],
          [180.2, 'angry'],
          [184.5, 'sad'],
        ],
        pose: [
          [172, 'idle'],
          [180.2, 'raise'],
          [184.5, 'idle'],
        ],
        tremble: true,
      },
      {
        id: 'haripada',
        x: 1060,
        flip: true,
        emo: 'sad',
        pose: 'idle',
        tremble: [
          [172, true],
        ],
      },
      {
        id: 'maya',
        x: 1600,
        flip: true,
        float: 70,
        emo: [
          [172, 'cold'],
          [191.9, 'angry'],
        ],
        pose: [
          [172, 'idle'],
          [191.9, 'raise'],
        ],
      },
    ],
    icons: [
      {type: 'warning', x: 1330, y: 420, size: 150, a: 192.2, b: 197.4},
    ],
    shake: [[191.9, 194, 5]],
    zoom: {a: 172, b: 180, s: 1.15, ox: 1060, oy: 480},
  },
  // ৯) প্রতিশোধের রাত, লণ্ঠন নিভে যাওয়া, নীরবতা
  {
    id: 's9',
    a: 197.8,
    b: 222,
    bg: {k: 'banyan', skeletonAt: 0},
    chars: [
      {id: 'ratan', x: 600, emo: 'fear', pose: 'cover', tremble: true, to: 217},
      {
        id: 'haripada',
        x: 1060,
        flip: true,
        emo: [
          [197.8, 'fear'],
          [204.2, 'sad'],
        ],
        pose: 'hold',
        tremble: true,
        lit: [
          [197.8, true],
          [203.8, false],
        ],
        to: 216.8,
      },
      {
        id: 'maya',
        x: 1560,
        flip: true,
        float: 70,
        emo: [
          [197.8, 'cold'],
          [209.9, 'angry'],
        ],
        pose: [
          [197.8, 'raise'],
          [209.9, 'point'],
        ],
        aboveDark: true,
        to: 221.8,
      },
    ],
    dark: [
      [198, 0],
      [199, 0.05],
      [203.8, 0.72],
      [216.4, 0.72],
      [217.2, 0.93],
      [221.5, 0.95],
    ],
    shake: [[216.5, 217.6, 14]],
    flash: [216.6],
  },
  // ১০) পরদিন: রতন অজ্ঞান, কঙ্কাল ও নূপুর
  {
    id: 's10',
    a: 222,
    b: 247,
    bg: {k: 'banyan', skeletonAt: 0},
    tint: 'rgba(255,196,130,0.14)',
    place: {text: 'বটগাছের নিচে · ভোর', a: 222.4},
    chars: [
      {
        id: 'ratan',
        x: 1060,
        emo: [
          [222, 'sleep'],
          [244.6, 'fear'],
        ],
        pose: 'idle',
        lying: [
          [222, true],
          [244.6, false],
        ],
      },
      {
        id: 'payel',
        x: 1480,
        flip: true,
        emo: 'fear',
        pose: [
          [222, 'raise'],
          [227.6, 'hug'],
        ],
        tremble: true,
      },
    ],
    stamps: [
      {text: 'হরিপদ নিখোঁজ', x: 960, y: 300, rot: -5, color: '#ff6b5e', size: 92, a: 231.0, b: 235.6},
      {text: 'নিতাই নিখোঁজ', x: 960, y: 300, rot: 4, color: '#ff6b5e', size: 92, a: 240.0, b: 244.0},
    ],
    icons: [
      {type: 'skull', x: 330, y: 790, size: 140, a: 235.8, b: 238.6},
      {type: 'nupur', x: 650, y: 840, size: 130, a: 236.4, b: 238.6},
    ],
  },
  // ১১) রাতে দরজার বাইরে
  {
    id: 's11',
    a: 247,
    b: 276.4,
    bg: {k: 'home', v: 'door', knocks: [271.0, 271.9, 272.8, 274.0]},
    place: {text: 'রতনের বাড়ি · মধ্যরাত', a: 247.4},
    dark: [
      [247, 0.25],
      [276, 0.3],
    ],
    chars: [
      {
        id: 'ratan',
        x: 700,
        emo: [
          [247, 'fear'],
          [250.9, 'shock'],
        ],
        pose: [
          [247, 'hug'],
          [262.9, 'cover'],
          [270.5, 'hug'],
        ],
        tremble: true,
      },
      {id: 'maya', x: 1450, flip: true, from: 250.9, to: 257.8, float: 40, emo: 'cold', pose: 'raise', opacity: 0.85, aboveDark: true},
      {id: 'nitai', x: 1450, flip: true, from: 258.2, to: 270.6, ghost: true, emo: 'sad', pose: 'idle', opacity: 0.85, aboveDark: true, float: 30},
      {id: 'maya', x: 1450, flip: true, from: 270.9, to: 276.4, float: 40, emo: 'cold', pose: 'raise', opacity: 0.85, aboveDark: true},
    ],
    icons: [
      {type: 'nupur', x: 1100, y: 470, size: 170, a: 247.4, b: 250.4},
      {type: 'exclaim', x: 960, y: 420, size: 120, a: 271.0, b: 273.1},
    ],
    stamps: [{text: 'তিন দিন আগেই মৃত', x: 960, y: 250, rot: -4, color: '#ff6b5e', size: 84, a: 265.6, b: 270.4}],
    shake: [
      [271.0, 271.2, 4],
      [271.9, 272.1, 4],
      [272.8, 273.0, 4],
    ],
  },
  // ১২) সমাপনী
  {
    id: 's12',
    a: 276.4,
    b: 290,
    bg: {k: 'clean'},
    cards: [
      {k: 'info', a: 276.6, b: 283.3, icon: 'nupur', title: 'নূপুরের শব্দ', sub: 'রাত ১২টার পর', color: '#f2c230'},
      {k: 'quote', a: 283.5, b: 289.9, small: 'মনে রেখো', text: 'সে খুঁজছে তার পরবর্তী শিকার'},
    ],
  },
];
