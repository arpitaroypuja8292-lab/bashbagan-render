import React from 'react';
import {useCurrentFrame} from 'remotion';
import {clamp, FPS, pop} from './utils';
import {Icon, IconType} from './Icons';
import {FONT} from './UI';

const O = '#222222';

export type CardCfg =
  | {k: 'title'; a: number; b: number; title: string; sub: string}
  | {k: 'info'; a: number; b: number; icon: IconType; title: string; sub: string; color: string}
  | {k: 'clock'; a: number; b: number; title: string; sub: string}
  | {k: 'cal'; a: number; b: number; big: string; label: string; title: string}
  | {k: 'seven'; a: number; b: number; title: string; stamp: string}
  | {k: 'wave'; a: number; b: number; title: string; sub: string}
  | {k: 'quote'; a: number; b: number; small: string; text: string};

const Wrap: React.FC<{a: number; b: number; children: React.ReactNode}> = ({a, b, children}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const p = pop(frame, a, 14, 130);
  const out = clamp((b - t) / 0.3, 0, 1);
  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        opacity: clamp(p * 1.4, 0, 1) * out,
        transform: `scale(${0.85 + 0.15 * p})`,
        fontFamily: FONT,
      }}
    >
      {children}
    </div>
  );
};

const panel: React.CSSProperties = {
  background: 'rgba(10,16,24,0.78)',
  borderRadius: 44,
  padding: '46px 70px 56px',
  display: 'flex',
  alignItems: 'center',
  gap: 56,
  boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
};

const Big: React.FC<{children: React.ReactNode; size?: number; color?: string}> = ({children, size = 130, color = '#fff'}) => (
  <div style={{fontSize: size, fontWeight: 700, color, lineHeight: 1.1, textShadow: '0 4px 16px rgba(0,0,0,0.5)'}}>{children}</div>
);

const Tag: React.FC<{children: React.ReactNode; color: string; size?: number}> = ({children, color, size = 56}) => (
  <div
    style={{
      display: 'inline-block',
      marginTop: 18,
      fontSize: size,
      fontWeight: 700,
      color,
      border: `6px solid ${color}`,
      borderRadius: 18,
      padding: '0 28px 6px',
      transform: 'rotate(-3deg)',
    }}
  >
    {children}
  </div>
);

export const CardView: React.FC<{c: CardCfg}> = ({c}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  switch (c.k) {
    case 'title': {
      const line = clamp((t - c.a - 0.6) / 0.9, 0, 1);
      return (
        <Wrap a={c.a} b={c.b}>
          <div style={{textAlign: 'center'}}>
            <div style={{fontSize: 58, color: '#cfe0f0', fontWeight: 500, letterSpacing: 2, textShadow: '0 3px 10px #000'}}>{c.sub}</div>
            <div style={{fontSize: 230, fontWeight: 700, color: '#fff', lineHeight: 1.15, textShadow: '0 0 40px rgba(180,210,255,0.6), 0 8px 24px #000'}}>
              {c.title}
            </div>
            <div style={{margin: '10px auto 0', height: 8, width: 620 * line, borderRadius: 4, background: '#ffd23f'}} />
          </div>
        </Wrap>
      );
    }
    case 'info':
      return (
        <Wrap a={c.a} b={c.b}>
          <div style={{...panel, border: `6px solid ${c.color}`}}>
            <div style={{transform: `scale(${1 + Math.sin(frame / 8) * 0.05})`}}>
              <Icon type={c.icon} size={240} frame={frame} />
            </div>
            <div>
              <Big size={150}>{c.title}</Big>
              <Tag color={c.color}>{c.sub}</Tag>
            </div>
          </div>
        </Wrap>
      );
    case 'clock': {
      const k = clamp((t - c.a - 0.3) / 2.2, 0, 1);
      const e = 1 - Math.pow(1 - k, 3);
      const minAng = -60 + 60 * e; // sweeps up to 12
      const hrAng = -2 + 2 * e;
      return (
        <Wrap a={c.a} b={c.b}>
          <div style={{...panel, border: '6px solid #7aa7d9'}}>
            <svg width={340} height={340} viewBox="0 0 200 200">
              <circle cx={100} cy={100} r={92} fill="#f6f1e4" stroke={O} strokeWidth={6} />
              {Array.from({length: 12}).map((_, i) => (
                <line key={i} x1={100} y1={14} x2={100} y2={i % 3 === 0 ? 30 : 22} stroke={O} strokeWidth={i % 3 === 0 ? 6 : 3} transform={`rotate(${i * 30} 100 100)`} />
              ))}
              <line x1={100} y1={100} x2={100} y2={44} stroke={O} strokeWidth={8} strokeLinecap="round" transform={`rotate(${hrAng} 100 100)`} />
              <line x1={100} y1={100} x2={100} y2={26} stroke="#c0392b" strokeWidth={5} strokeLinecap="round" transform={`rotate(${minAng} 100 100)`} />
              <circle cx={100} cy={100} r={8} fill={O} />
            </svg>
            <div>
              <Big size={170}>{c.title}</Big>
              <Tag color="#ff6b5e">{c.sub}</Tag>
            </div>
          </div>
        </Wrap>
      );
    }
    case 'cal': {
      const hp = pop(frame, c.a + 1.6, 9, 160);
      return (
        <Wrap a={c.a} b={c.b}>
          <div style={{...panel, border: '6px solid #f2c230'}}>
            <div style={{width: 330, borderRadius: 26, overflow: 'hidden', border: `5px solid ${O}`, background: '#fffaf0', textAlign: 'center'}}>
              <div style={{background: '#d9453a', color: '#fff', fontSize: 52, fontWeight: 700, padding: '2px 0 6px'}}>{c.label}</div>
              <div style={{fontSize: 200, fontWeight: 700, color: O, lineHeight: 1.15}}>{c.big}</div>
            </div>
            <div style={{display: 'flex', alignItems: 'center', gap: 30}}>
              <Big size={140}>{c.title}</Big>
              <div style={{transform: `scale(${hp * (1 + Math.sin(frame / 7) * 0.06)})`}}>
                <Icon type="heart" size={130} />
              </div>
            </div>
          </div>
        </Wrap>
      );
    }
    case 'seven': {
      const stampP = pop(frame, c.a + 3.0, 9, 220);
      return (
        <Wrap a={c.a} b={c.b}>
          <div style={{...panel, flexDirection: 'column', gap: 34, border: '6px solid #7aa7d9'}}>
            <Big size={110}>{c.title}</Big>
            <div style={{display: 'flex', gap: 22, position: 'relative'}}>
              {['১', '২', '৩', '৪', '৫', '৬', '৭'].map((d, i) => {
                const p = pop(frame, c.a + 0.5 + i * 0.35, 12, 200);
                const last = i === 6 && stampP > 0.5;
                return (
                  <div
                    key={d}
                    style={{
                      width: 112,
                      height: 128,
                      borderRadius: 20,
                      border: `5px solid ${O}`,
                      background: last ? '#c0392b' : '#fffaf0',
                      color: last ? '#fff' : O,
                      fontSize: 80,
                      fontWeight: 700,
                      textAlign: 'center',
                      lineHeight: 1.45,
                      transform: `scale(${p})`,
                    }}
                  >
                    {d}
                  </div>
                );
              })}
            </div>
            <div style={{opacity: stampP, transform: `rotate(-4deg) scale(${1 + (1 - stampP) * 1.2})`}}>
              <Tag color="#ff6b5e" size={84}>
                {c.stamp}
              </Tag>
            </div>
          </div>
        </Wrap>
      );
    }
    case 'wave':
      return (
        <Wrap a={c.a} b={c.b}>
          <div style={{...panel, flexDirection: 'column', gap: 26, border: '6px solid #9ad0ff'}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 6, height: 220}}>
              {Array.from({length: 31}).map((_, i) => {
                const h = 24 + Math.abs(Math.sin(frame / 6 + i * 0.55) * Math.cos(frame / 17 + i * 0.2)) * 190;
                return <div key={i} style={{width: 16, height: h, borderRadius: 8, background: '#9ad0ff', border: `3px solid ${O}`}} />;
              })}
            </div>
            <div style={{display: 'flex', alignItems: 'center', gap: 30}}>
              <Icon type="moon" size={120} />
              <div>
                <Big size={120}>{c.title}</Big>
              </div>
            </div>
            <div style={{fontSize: 56, color: '#cfe0f0', fontWeight: 500}}>{c.sub}</div>
          </div>
        </Wrap>
      );
    case 'quote': {
      const k = clamp((t - c.a - 0.8) / 1.2, 0, 1);
      return (
        <Wrap a={c.a} b={c.b}>
          <div style={{...panel, flexDirection: 'column', gap: 18, border: '6px solid #c0392b', maxWidth: 1500, textAlign: 'center'}}>
            <div style={{fontSize: 64, color: '#cfe0f0', fontWeight: 500}}>{c.small}</div>
            <div style={{display: 'flex', alignItems: 'center', gap: 40}}>
              <div style={{transform: `scale(${1 + Math.sin(frame / 7) * 0.07})`}}>
                <Icon type="nupur" size={190} />
              </div>
              <Big size={118} color="#ffd23f">
                {c.text}
              </Big>
            </div>
            <div style={{height: 8, width: 900 * k, borderRadius: 4, background: '#c0392b'}} />
          </div>
        </Wrap>
      );
    }
  }
};
