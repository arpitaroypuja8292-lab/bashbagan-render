import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Background} from './Backgrounds';
import {Character, HEAD_TOP, floatOffset} from './Character';
import {CardView} from './Cards';
import {Bubble, Caption, IconPop, NameBadge, PlacePill, Stamp} from './UI';
import {Cue, CharCfg, SceneCfg, cues} from './story';
import {FPS, clamp, jitter, lerp, tl} from './utils';

const FY = 900;
const SC = 1.3;

const charX = (c: CharCfg, t: number) => {
  if (!c.move) return c.x;
  const k = clamp((t - c.move.a) / (c.move.b - c.move.a), 0, 1);
  return lerp(c.x, c.move.x1, k);
};

const cache = new Map<string, Cue[]>();
const sceneCues = (sc: SceneCfg) => {
  let r = cache.get(sc.id);
  if (!r) {
    r = cues.filter((q) => q.s >= sc.a - 0.001 && q.s < sc.b);
    cache.set(sc.id, r);
  }
  return r;
};

export const SceneView: React.FC<{sc: SceneCfg}> = ({sc}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const fade = clamp((t - sc.a) / 0.3, 0, 1);

  let sx = 0;
  let sy = 0;
  for (const [a, b, amp] of sc.shake ?? []) {
    if (t >= a && t < b) {
      const j = jitter(frame, amp);
      sx += j.x;
      sy += j.y;
    }
  }
  let zs = 1;
  if (sc.zoom) {
    const z = sc.zoom;
    zs = 1 + (z.s - 1) * clamp((t - z.a) / 0.6, 0, 1) * clamp((z.b - t) / 0.6, 0, 1);
  }
  const ox = sc.zoom?.ox ?? 960;
  const oy = sc.zoom?.oy ?? 540;
  const zp = (x: number, y: number) => ({x: (x - ox) * zs + ox + sx, y: (y - oy) * zs + oy + sy});

  const sq = sceneCues(sc);
  const active = sq.find((q) => t >= q.s && t < q.e);
  const chars = sc.chars ?? [];

  const isVisible = (c: CharCfg, at: number) => at >= (c.from ?? -1) && at < (c.to ?? 1e9);

  const renderChar = (c: CharCfg, i: number) => {
    if (!isVisible(c, t)) return null;
    const op =
      (c.opacity ?? 1) *
      (c.from !== undefined ? clamp((t - c.from) / 0.45, 0, 1) : 1) *
      (c.to !== undefined ? clamp((c.to - t) / 0.35, 0, 1) : 1);
    const talking = sq.some((q) => q.who === c.id && t >= q.s && t < q.e);
    return (
      <Character
        key={i}
        id={c.id}
        x={charX(c, t)}
        y={c.y ?? FY}
        s={c.s ?? SC}
        flip={c.flip}
        emo={tl(c.emo, t, 'neutral')}
        pose={tl(c.pose, t, 'idle')}
        talking={talking}
        ghost={c.ghost}
        lying={tl(c.lying, t, false)}
        walk={tl(c.walk, t, false)}
        float={c.float}
        tremble={tl(c.tremble, t, false)}
        lit={tl(c.lit, t, true)}
        opacity={op}
      />
    );
  };

  const darkOp = sc.dark
    ? interpolate(
        t,
        sc.dark.map((d) => d[0]),
        sc.dark.map((d) => d[1]),
        {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'},
      )
    : 0;

  const blocked =
    (sc.cards ?? []).some((c) => t >= c.a && t < c.b) || (sc.stamps ?? []).some((s) => t >= s.a && t < s.b);

  // speech bubbles
  const bubbles = sq
    .filter((q) => q.who !== 'N' && t >= q.s && t < q.e + 0.2)
    .map((q) => {
      const cfg = chars.find((c) => c.id === q.who && isVisible(c, Math.max(t, q.s) + 0.001));
      if (!cfg) return null;
      const s = cfg.s ?? SC;
      const p = zp(charX(cfg, t), (cfg.y ?? FY) + floatOffset(cfg.float, frame) - HEAD_TOP * s);
      return (
        <Bubble
          key={q.s}
          text={q.t}
          ax={p.x}
          ay={p.y}
          a={q.s}
          b={q.e}
          color={q.who === 'maya' ? '#e6f0ff' : '#fffaf0'}
        />
      );
    });

  return (
    <AbsoluteFill style={{opacity: fade, overflow: 'hidden'}}>
      <div style={{position: 'absolute', left: 0, top: 0, width: 1920, height: 1080, transformOrigin: '0 0', transform: `translate(${sx}px,${sy}px) translate(${ox}px,${oy}px) scale(${zs}) translate(${-ox}px,${-oy}px)`}}>
        <Background cfg={sc.bg} />
        <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
          {chars.map((c, i) => (c.aboveDark ? null : renderChar(c, i)))}
        </svg>
        {darkOp > 0 && <div style={{position: 'absolute', inset: 0, background: `rgba(2,4,8,${darkOp})`}} />}
        <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
          {chars.map((c, i) => (c.aboveDark ? renderChar(c, i) : null))}
        </svg>
      </div>

      {sc.tint && <div style={{position: 'absolute', inset: 0, background: sc.tint}} />}

      {(sc.icons ?? []).map((ic, i) => (
        <IconPop key={i} {...ic} />
      ))}
      {(sc.cards ?? []).map((c, i) => (t >= c.a - 0.05 && t < c.b + 0.1 ? <CardView key={i} c={c} /> : null))}
      {(sc.stamps ?? []).map((s, i) => (t >= s.a - 0.05 && t < s.b + 0.1 ? <Stamp key={i} {...s} /> : null))}
      {(sc.badges ?? []).map((bd, i) => {
        const cfg = chars.find((c) => c.id === bd.id);
        if (!cfg || t < bd.a - 0.05 || t > bd.b + 0.1) return null;
        const p = zp(charX(cfg, t), (cfg.y ?? FY) + 30);
        return <NameBadge key={i} text={bd.text} color={bd.color} x={p.x} y={p.y} a={bd.a} b={bd.b} />;
      })}
      {sc.place && <PlacePill text={sc.place.text} a={sc.place.a} />}
      {bubbles}

      {active && active.who === 'N' && !blocked && <Caption key={active.s} text={active.t} a={active.s} b={active.e} />}

      {(sc.flash ?? []).map((f, i) => {
        const k = clamp(1 - (t - f) / 0.35, 0, 1);
        return t >= f && k > 0 ? <div key={i} style={{position: 'absolute', inset: 0, background: '#fff', opacity: k * 0.85}} /> : null;
      })}
    </AbsoluteFill>
  );
};
