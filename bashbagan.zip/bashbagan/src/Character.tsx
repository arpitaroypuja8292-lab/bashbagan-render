import React from 'react';
import {useCurrentFrame} from 'remotion';

export type CharId = 'ratan' | 'maya' | 'haripada' | 'nitai' | 'payel';
export type Emo = 'neutral' | 'smile' | 'fear' | 'shock' | 'sad' | 'angry' | 'cold' | 'sleep' | 'worry';
export type Pose = 'idle' | 'point' | 'cover' | 'raise' | 'hold' | 'wave' | 'hug';

const OUT = '#222222';
const SKIN: Record<CharId, string> = {
  ratan: '#b9855a',
  maya: '#e6edf1',
  haripada: '#a97a52',
  nitai: '#b88d66',
  payel: '#c68f64',
};
const SEED: Record<CharId, number> = {ratan: 1, maya: 2, haripada: 3, nitai: 4, payel: 5};
const TOP: Record<CharId, string> = {
  ratan: '#8d7a5c',
  maya: '#f1f1f1',
  haripada: '#b9a77f',
  nitai: '#efece4',
  payel: '#b23a48',
};
const SLEEVE: Record<CharId, number> = {ratan: 72, maya: 60, haripada: 104, nitai: 96, payel: 46};
const BROW: Record<CharId, string> = {
  ratan: '#1b1b1b',
  maya: '#111',
  haripada: '#e8e8e8',
  nitai: '#e8e8e8',
  payel: '#111',
};

/** pixels above feet (unscaled) where the top of the hair is */
export const HEAD_TOP = 462;

export const floatOffset = (float: number | undefined, frame: number) =>
  float ? -float - Math.sin(frame / 18) * 16 : 0;

const armAngles = (pose: Pose, frame: number, swing: number): [number, number] => {
  switch (pose) {
    case 'point':
      return [7, -88];
    case 'cover':
      return [-150, 150];
    case 'raise':
      return [140, -140];
    case 'hold':
      return [7, -50];
    case 'wave':
      return [7, -140 + Math.sin(frame / 3) * 16];
    case 'hug':
      return [-96, 96];
    default:
      return [7 + swing * 24, -7 + swing * 24];
  }
};

type ArmProps = {
  side: -1 | 1;
  angle: number;
  skin: string;
  sleeve: string;
  len: number;
  sw: number;
  bangles?: boolean;
  children?: React.ReactNode;
};
const Arm: React.FC<ArmProps> = ({side, angle, skin, sleeve, len, sw, bangles, children}) => (
  <g transform={`translate(${side * 62},-282) rotate(${angle})`}>
    <rect x={-13} y={-10} width={26} height={132} rx={13} fill={skin} stroke={OUT} strokeWidth={sw} />
    <rect x={-13} y={-10} width={26} height={len} rx={13} fill={sleeve} stroke={OUT} strokeWidth={sw} />
    {bangles && (
      <g>
        {[88, 98, 108].map((yy, i) => (
          <rect key={yy} x={-14} y={yy} width={28} height={6} rx={3} fill={i === 1 ? '#f4f4f4' : '#d33'} stroke={OUT} strokeWidth={sw * 0.8} />
        ))}
      </g>
    )}
    <g transform={`translate(0,124) rotate(${-angle})`}>{children}</g>
  </g>
);

const Lantern: React.FC<{lit: boolean; frame: number; sw: number}> = ({lit, frame, sw}) => {
  const f = lit ? 0.8 + Math.sin(frame * 0.7) * 0.12 + Math.sin(frame * 1.9) * 0.08 : 0;
  return (
    <g>
      {lit && <circle cx={0} cy={40} r={240} fill="url(#lanternGlow)" opacity={f} />}
      <path d="M-14 6 Q0 -22 14 6" fill="none" stroke={OUT} strokeWidth={sw * 1.4} />
      <rect x={-17} y={6} width={34} height={52} rx={7} fill={lit ? '#ffd36a' : '#555'} stroke={OUT} strokeWidth={sw} />
      <rect x={-10} y={14} width={20} height={36} rx={4} fill={lit ? '#fff0b0' : '#2b2b2b'} />
      <rect x={-20} y={54} width={40} height={8} rx={3} fill="#3a2e1c" stroke={OUT} strokeWidth={sw} />
    </g>
  );
};

const Stick: React.FC<{sw: number}> = ({sw}) => (
  <rect x={-4.5} y={-14} width={9} height={176} rx={4.5} fill="#7a5632" stroke={OUT} strokeWidth={sw} />
);

type FaceProps = {id: CharId; emo: Emo; talking: boolean; frame: number; ghost: boolean; sw: number};
const Face: React.FC<FaceProps> = ({id, emo, talking, frame, ghost, sw}) => {
  const seed = SEED[id];
  const blink = emo === 'sleep' || (frame + seed * 37) % 110 < 4;
  const wide = emo === 'fear' || emo === 'shock';
  const rx = wide ? 14 : 11;
  const ry = blink ? 1.6 : wide ? 17 : 13;
  const maya = id === 'maya';
  const cloudy = ghost && id === 'nitai';
  const lift = emo === 'shock' ? -12 : emo === 'fear' ? -8 : 0;
  const ang = emo === 'angry' ? 18 : emo === 'sad' || emo === 'fear' ? -16 : emo === 'worry' ? -11 : 0;
  const eyeFill = maya ? '#0a0a0a' : cloudy ? '#cfd8d8' : '#ffffff';
  const dark = '#4a1d1d';
  const line = (d: string) => <path d={d} fill="none" stroke={OUT} strokeWidth={sw * 1.2} strokeLinecap="round" />;
  const open = (rxm: number, rym: number) => (
    <ellipse cx={0} cy={-332} rx={rxm} ry={rym} fill={dark} stroke={OUT} strokeWidth={sw} />
  );
  const m = [0, 1, 2, 1, 0, 2, 1, 2][Math.floor(frame / 4 + seed) % 8];

  let mouth: React.ReactNode;
  if (talking) {
    mouth = m === 0 ? line('M-12 -332 L12 -332') : m === 1 ? open(10, 6) : open(14, 13);
  } else {
    switch (emo) {
      case 'smile':
        mouth = line('M-18 -336 Q0 -316 18 -336');
        break;
      case 'cold':
        mouth = line('M-18 -333 Q2 -322 22 -343');
        break;
      case 'sad':
        mouth = line('M-15 -328 Q0 -342 15 -328');
        break;
      case 'angry':
        mouth = line('M-16 -330 Q0 -338 16 -330');
        break;
      case 'worry':
        mouth = line('M-14 -331 Q-7 -336 0 -331 Q7 -326 14 -331');
        break;
      case 'fear':
        mouth = open(9 + Math.sin(frame / 2) * 1.2, 11);
        break;
      case 'shock':
        mouth = open(12, 17);
        break;
      default:
        mouth = line('M-12 -332 L12 -332');
    }
  }

  const tearPh = (frame % 24) / 24;
  return (
    <g>
      {[-24, 24].map((ex) => (
        <g key={ex}>
          <ellipse cx={ex} cy={-376} rx={rx} ry={ry} fill={eyeFill} stroke={OUT} strokeWidth={sw} />
          {!blink && !maya && <circle cx={ex} cy={-376} r={wide ? 3.5 : 5.5} fill={cloudy ? '#9aa8aa' : '#1a1a1a'} />}
          {!blink && maya && <circle cx={ex + 4} cy={-381} r={2.6} fill="#fff" opacity={0.35} />}
          {emo === 'sad' && (
            <ellipse cx={ex} cy={-352 + tearPh * 38} rx={4} ry={6} fill="#7fc4ff" opacity={1 - tearPh} />
          )}
        </g>
      ))}
      {id === 'nitai' && (
        <g>
          {[-24, 24].map((ex) => (
            <circle key={ex} cx={ex} cy={-376} r={23} fill="rgba(200,230,255,0.28)" stroke={OUT} strokeWidth={sw * 1.7} />
          ))}
          <line x1={-1} y1={-378} x2={1} y2={-378} stroke={OUT} strokeWidth={sw * 1.7} />
        </g>
      )}
      {[-24, 24].map((ex, i) => (
        <line
          key={ex}
          x1={-15}
          y1={0}
          x2={15}
          y2={0}
          transform={`translate(${ex},${-404 + lift}) rotate(${i === 0 ? ang : -ang})`}
          stroke={BROW[id]}
          strokeWidth={6}
          strokeLinecap="round"
        />
      ))}
      <path d="M0 -366 Q7 -352 -1 -349" fill="none" stroke={OUT} strokeWidth={sw} />
      {mouth}
      {(emo === 'fear' || emo === 'shock') && (
        <path
          d={`M56 ${-420 + (frame % 40) * 0.5} q-9 14 0 20 q9 -6 0 -20z`}
          fill="#8fd0ff"
          stroke={OUT}
          strokeWidth={sw * 0.8}
        />
      )}
    </g>
  );
};

export type CharProps = {
  id: CharId;
  x: number;
  y: number;
  s: number;
  flip?: boolean;
  emo: Emo;
  pose: Pose;
  talking: boolean;
  ghost?: boolean;
  lying?: boolean;
  walk?: boolean;
  float?: number;
  tremble?: boolean;
  lit?: boolean;
  opacity?: number;
};

export const Character: React.FC<CharProps> = (p) => {
  const frame = useCurrentFrame();
  const {id, s} = p;
  const sw = 2.5 / s;
  const seed = SEED[id];
  const swing = p.walk ? Math.sin(frame / 5) : 0;
  const bob = Math.sin(frame / 14 + seed) * 3.5;
  const tr = p.tremble
    ? {x: Math.sin(frame * 2.3 + seed) * 3.2, y: Math.cos(frame * 3.1 + seed) * 2}
    : {x: 0, y: 0};
  const fl = floatOffset(p.float, frame);
  const ghostNitai = id === 'nitai' && !!p.ghost;
  const skin = ghostNitai ? '#c3d1d8' : SKIN[id];
  const [la, ra] = armAngles(p.pose, frame, swing);
  const tilt = id === 'nitai' ? 5 : 0;
  const glow = id === 'maya' || ghostNitai;
  const st = {stroke: OUT, strokeWidth: sw, strokeLinejoin: 'round' as const};
  const topCol = ghostNitai && id === 'nitai' ? '#dfe6ea' : TOP[id];

  const arms = (
    <>
      <Arm side={-1} angle={la} skin={skin} sleeve={topCol} len={SLEEVE[id]} sw={sw} bangles={id === 'payel'}>
        {id === 'nitai' && <Stick sw={sw} />}
      </Arm>
      <Arm side={1} angle={ra} skin={skin} sleeve={topCol} len={SLEEVE[id]} sw={sw} bangles={id === 'payel'}>
        {id === 'haripada' && <Lantern lit={p.lit ?? true} frame={frame} sw={sw} />}
      </Arm>
    </>
  );

  // ---------- garments ----------
  let bottom: React.ReactNode = null;
  switch (id) {
    case 'ratan':
      bottom = (
        <g>
          <path d="M-72 -150 L-88 -34 L88 -34 L72 -150Z" fill="#4f7a8a" {...st} />
          {[-42, -8, 26, 56].map((xx) => (
            <path key={xx} d={`M${xx} -148 L${xx * 1.1} -36`} stroke="#35596a" strokeWidth={sw * 1.6} />
          ))}
          {[-110, -75].map((yy) => (
            <path key={yy} d={`M${-76 - (yy + 150) * -0.2} ${yy} L${76 + (yy + 150) * -0.2} ${yy}`} stroke="#35596a" strokeWidth={sw * 1.4} />
          ))}
        </g>
      );
      break;
    case 'haripada':
    case 'nitai':
      bottom = (
        <g>
          <path
            d="M-74 -150 L-90 -40 L-30 -36 L0 -46 L30 -36 L90 -40 L74 -150Z"
            fill={ghostNitai ? '#dfe6ea' : id === 'haripada' ? '#e8e2d2' : '#f1eee6'}
            {...st}
          />
          <path d="M0 -150 L-6 -60 M-30 -140 L-40 -60 M30 -140 L38 -60" stroke="#b9b29c" strokeWidth={sw * 1.3} fill="none" />
        </g>
      );
      break;
    case 'payel':
      bottom = (
        <g>
          <path d="M-74 -150 L-96 -22 L96 -22 L74 -150Z" fill="#d9784f" {...st} />
          <path d="M-40 -150 L-52 -24 M0 -150 L0 -24 M40 -150 L52 -24" stroke="#b25a36" strokeWidth={sw * 1.5} fill="none" />
          <path d="M-96 -34 L96 -34" stroke="#f2d9a8" strokeWidth={sw * 4} fill="none" />
        </g>
      );
      break;
    case 'maya':
      bottom = (
        <g>
          <path
            d="M-72 -150 L-98 -44 L-82 -10 L-64 -42 L-46 -4 L-28 -40 L-8 -2 L10 -42 L30 -6 L50 -44 L68 -8 L86 -38 L98 -44 L72 -150Z"
            fill="#f2f2f2"
            {...st}
          />
          <path d="M-30 -140 L-40 -50 M20 -140 L26 -50 M50 -120 L66 -60" stroke="#c9ced1" strokeWidth={sw * 1.4} fill="none" />
          {[-34, 34].map((xx) => (
            <g key={xx}>
              <ellipse cx={xx} cy={0} rx={22} ry={8} fill="#dfe8ec" stroke={OUT} strokeWidth={sw} />
              <ellipse cx={xx} cy={-22} rx={18} ry={6} fill="none" stroke="#b8892b" strokeWidth={sw * 2.4} />
            </g>
          ))}
        </g>
      );
      break;
  }

  // ---------- upper body decoration ----------
  let topDeco: React.ReactNode = null;
  if (id === 'ratan')
    topDeco = (
      <g>
        {[
          [-42, -256],
          [0, -272],
          [42, -250],
          [-30, -206],
          [22, -220],
          [52, -184],
          [-56, -172],
          [2, -168],
        ].map(([cx, cy], i) => (
          <circle key={i} cx={cx} cy={cy} r={6} fill="#6a5a42" />
        ))}
        <path d="M-22 -300 L0 -262 L22 -300" fill="none" stroke={OUT} strokeWidth={sw} />
        <path d="M34 -302 L74 -284 L68 -184 L44 -190Z" fill="#c0392b" {...st} />
        <path d="M40 -250 L71 -240 M42 -222 L70 -214" stroke="#fff" strokeWidth={sw * 2} />
      </g>
    );
  if (id === 'haripada')
    topDeco = (
      <g>
        <path d="M0 -298 L0 -134" stroke={OUT} strokeWidth={sw} />
        {[-260, -220, -180].map((yy) => (
          <circle key={yy} cx={8} cy={yy} r={4} fill="#6e5f3d" stroke={OUT} strokeWidth={sw * 0.7} />
        ))}
      </g>
    );
  if (id === 'nitai')
    topDeco = (
      <path d="M-70 -292 L68 -246 L70 -150 L2 -136 L-70 -210Z" fill={ghostNitai ? '#b9c6cc' : '#cfc9b6'} {...st} />
    );
  if (id === 'payel')
    topDeco = (
      <g>
        <path d="M-62 -298 L68 -250 L70 -138 L30 -138 L-44 -226Z" fill="#d9784f" {...st} />
        <path d="M-40 -280 L56 -244 M-30 -262 L58 -228" stroke="#f2d9a8" strokeWidth={sw * 2.2} />
      </g>
    );
  if (id === 'maya')
    topDeco = (
      <g>
        <path d="M-50 -270 L-30 -250 M20 -210 L44 -190 M-20 -170 L-8 -140" stroke="#c9ced1" strokeWidth={sw * 1.6} />
        <path d="M-70 -200 l10 8 l-6 10 l12 6" fill="none" stroke="#c9ced1" strokeWidth={sw * 1.4} />
      </g>
    );

  // ---------- hair / head extras ----------
  let backHair: React.ReactNode = null;
  let frontHair: React.ReactNode = null;
  switch (id) {
    case 'maya':
      backHair = (
        <path
          d="M-78 -400 C-116 -300 -104 -130 -62 -56 L62 -56 C104 -130 116 -300 78 -400 C40 -466 -40 -466 -78 -400Z"
          fill="#0d0d0d"
          {...st}
        />
      );
      frontHair = (
        <g>
          <path
            d="M-62 -392 C-66 -450 66 -450 62 -392 C44 -404 14 -398 8 -366 C0 -330 -26 -296 -48 -306 C-64 -326 -64 -360 -62 -392Z"
            fill="#0d0d0d"
            stroke={OUT}
            strokeWidth={sw}
          />
          <path d="M28 -400 C40 -370 34 -340 44 -300" fill="none" stroke="#0d0d0d" strokeWidth={14} strokeLinecap="round" />
        </g>
      );
      break;
    case 'ratan':
      frontHair = (
        <g>
          <path d="M-60 -378 C-66 -466 66 -466 60 -378 C44 -414 -44 -414 -60 -378Z" fill="#1b1b1b" {...st} />
          <path d="M-52 -350 C-48 -304 48 -304 52 -350 C36 -326 -36 -326 -52 -350Z" fill="#3a2a22" opacity={0.55} />
        </g>
      );
      break;
    case 'haripada':
      frontHair = (
        <g>
          <path d="M-60 -372 C-70 -446 70 -446 60 -372 C50 -404 -50 -404 -60 -372Z" fill="#f2f2f2" {...st} />
          <path
            d="M-54 -352 C-54 -286 54 -286 54 -352 C34 -328 -34 -328 -54 -352Z"
            fill="#f2f2f2"
            stroke={OUT}
            strokeWidth={sw}
          />
          <path d="M-22 -416 Q0 -424 22 -416 M-18 -406 Q0 -412 18 -406" fill="none" stroke="#9c8f7a" strokeWidth={sw} />
        </g>
      );
      break;
    case 'nitai':
      frontHair = (
        <g>
          <ellipse cx={-54} cy={-384} rx={14} ry={26} fill="#f4f4f4" {...st} />
          <ellipse cx={54} cy={-384} rx={14} ry={26} fill="#f4f4f4" {...st} />
          <path d="M-46 -428 Q0 -450 46 -428" fill="none" stroke="#f4f4f4" strokeWidth={9} strokeLinecap="round" />
          <path d="M-46 -428 Q0 -450 46 -428" fill="none" stroke={OUT} strokeWidth={sw * 0.8} opacity={0.5} />
        </g>
      );
      break;
    case 'payel':
      backHair = (
        <g>
          <path d="M44 -340 C104 -300 104 -220 80 -130" fill="none" stroke={OUT} strokeWidth={26} strokeLinecap="round" />
          <path d="M44 -340 C104 -300 104 -220 80 -130" fill="none" stroke="#111" strokeWidth={21} strokeLinecap="round" />
        </g>
      );
      frontHair = (
        <g>
          <path d="M-58 -376 C-66 -456 66 -456 58 -376 C40 -420 -40 -420 -58 -376Z" fill="#111" {...st} />
          <path d="M0 -440 L0 -414" stroke="#d11" strokeWidth={5} />
          <circle cx={0} cy={-398} r={4} fill="#d11" />
        </g>
      );
      break;
  }

  const inner = (
    <>
      {backHair}
      {id !== 'maya' &&
        [-1, 1].map((sd) => (
          <g key={sd} transform={`translate(${sd * 28},-140) rotate(${sd * swing * 20})`}>
            <rect x={-14} y={0} width={28} height={130} rx={13} fill={skin} stroke={OUT} strokeWidth={sw} />
            <ellipse cx={sd * 4} cy={130} rx={24} ry={11} fill="#3a2a1c" stroke={OUT} strokeWidth={sw} />
          </g>
        ))}
      <g transform={`rotate(${tilt} 0 -140)`}>
        <rect x={-70} y={-300} width={140} height={172} rx={34} fill={topCol} {...st} />
        {topDeco}
        {bottom}
        <g transform={`translate(0,${bob})`}>
          {p.pose !== 'cover' && arms}
          <circle cx={-58} cy={-372} r={11} fill={skin} {...st} />
          <circle cx={58} cy={-372} r={11} fill={skin} {...st} />
          <ellipse cx={0} cy={-372} rx={58} ry={66} fill={skin} {...st} />
          {frontHair}
          <Face id={id} emo={p.emo} talking={p.talking} frame={frame} ghost={!!p.ghost} sw={sw} />
          {p.pose === 'cover' && arms}
        </g>
      </g>
    </>
  );

  return (
    <g>
      <defs>
        <radialGradient id="lanternGlow">
          <stop offset="0" stopColor="#ffd76a" stopOpacity={0.75} />
          <stop offset="1" stopColor="#ffd76a" stopOpacity={0} />
        </radialGradient>
      </defs>
      {!p.lying && (
        <ellipse
          cx={p.x}
          cy={p.y + 6}
          rx={90 * s}
          ry={14 * s}
          fill="rgba(0,0,0,0.35)"
          opacity={(p.opacity ?? 1) * (id === 'maya' ? 0.5 : 1)}
        />
      )}
      <g
        transform={`translate(${p.x + tr.x},${p.y + fl + tr.y}) scale(${p.flip ? -s : s},${s})`}
        opacity={p.opacity ?? 1}
        style={glow ? {filter: 'drop-shadow(0 0 22px rgba(170,205,255,0.75))'} : undefined}
      >
        <g transform={p.lying ? 'translate(0,-55) rotate(-90)' : undefined}>{inner}</g>
      </g>
    </g>
  );
};
